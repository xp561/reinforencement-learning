import torch.cuda

import env_core
import env_wrappers

from env_wrappers import DummyVecEnv

def make_train_env(num_thread=5):
    def get_env(rank):
        def init_env():
            from env_discrete import DiscreteActionEnv
            env = DiscreteActionEnv()
            env.seed(rank)
            return env
        return init_env()
    return DummyVecEnv([get_env(i) for i in range(num_thread)])


if __name__=="__main__()":
    envs = make_train_env()
    envs.reset()
    # for i in range(100):
    #     print(envs.step([[0,0,0,0] for i in range(5)]))
    if torch.cuda.is_available():
        device = torch.device("cuda:0")
    else:
        device = torch.device("cpu")
    config = {
        # "all_args": all_args,
        "envs": envs,
        # "eval_envs": eval_envs,
        # "num_agents": num_agents,
        "device": device,
        # "run_dir": run_dir,
    }
