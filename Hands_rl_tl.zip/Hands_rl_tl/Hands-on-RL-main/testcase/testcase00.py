
two_dim_list = [[0,1,2,]]
flat_list = [*sublist for sublist in two_dim_list]
