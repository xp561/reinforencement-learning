import time

import torch
import torch.nn.functional as F
import numpy as np
import rl_utils
from tqdm import tqdm
import matplotlib.pyplot as plt
import pandas as pd
from testcase_appo import make_train_env
from itertools import chain
"""
train.py    目前主要是训练代码，集成了replayerbuffer的功能
todo: 1. value net dim= agent_num*state_dim + agent_num*action_dim
         actor net dim = state_dim
"""
# ! git clone https://github.com/boyu-ai/ma-gym.git
import sys
sys.path.append("./ma-gym")

import os
from torch.utils.tensorboard import SummaryWriter
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
write = SummaryWriter('logs/exp_time')
from torch.utils.data import Dataset,DataLoader

device =   torch.device("cpu")#torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
class Dataset(Dataset):
    def __init__(self,advantage, value_target,share_obs,next_share_obs,actor_states,action_log_prob,td_target,actions,rewards):
        self.advantage=advantage
        self.value_target = value_target
        self.share_obs=share_obs
        self.next_share_obs = next_share_obs
        self.actor_states = actor_states
        self.action_log_prob = action_log_prob
        self.td_target = td_target
        self.actions = actions
        self.rewards = rewards
        # pass
    def __len__(self):
        length = self.advantage.shape[0]
        return length
    def __getitem__(self, idx):
        return (self.advantage[idx,:].to(device),self.value_target[idx,:].to(device),self.share_obs[idx,:].to(device), self.next_share_obs[idx,:].to(device),self.actor_states[idx,:].to(device),
                self.action_log_prob[idx,:].to(device),self.td_target[idx].to(device),self.actions[idx].to(device),self.rewards[idx].to(device))
        # pass

class PolicyNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim):
        super(PolicyNet, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = torch.nn.Linear(hidden_dim, action_dim)
        self.relu = torch.nn.ReLU(inplace=False)

    def forward(self, x):
        x = self.relu(self.fc2(self.relu(self.fc1(x))))
        return F.softmax(self.fc3(x), dim=1)

    def evaluate_acts(self,x,action, available_actions=None, active_masks=None):
        action_dist = self.forward(x,)
        action_log_probs = torch.log(action_dist.gather(1, action))
        # action_log_probs = action_logits.log_probs(action)
        if active_masks is not None:
            dist_entropy = (action_dist.entropy() * active_masks.squeeze(-1)).sum() / active_masks.sum()
        else:
            dist_entropy = -torch.sum(action_dist * torch.log(action_dist + 1e-10), dim=-1).mean()#action_dist.entropy().mean()

        return action_log_probs, dist_entropy

class ValueNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim):
        super(ValueNet, self).__init__()
        self.fc1 = torch.nn.Linear(state_dim, hidden_dim)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = torch.nn.Linear(hidden_dim, 1)
        self.relu = torch.nn.ReLU(inplace=False)
    def forward(self, x):
        # x = self.relu(self.fc2(self.relu(self.fc1(x))))
        x = self.fc1(x)
        x = self.fc2(x)
        # x = self.fc3(x)
        return self.fc3(x)


class PPO:
    ''' PPO算法,采用截断方式 '''
    def __init__(self, state_dim, hidden_dim, action_dim, actor_lr, critic_lr,
                 lmbda, eps, gamma, device):
        agent_num = 4
        critic_dim = state_dim * agent_num #+ agent_num
        self.actor = PolicyNet(state_dim, hidden_dim, action_dim).to(device)
        self.critic = ValueNet(critic_dim, hidden_dim).to(device)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),
                                                lr=actor_lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(),
                                                 lr=critic_lr)
        self.gamma = gamma
        self.lmbda = lmbda
        self.eps = eps  # PPO中截断范围的参数
        self.device = device
        self.batch_size = 4096
        self.entropy_coefficient = 0.01

    def take_action(self, state, share_ob=None,mask=None):
        state = torch.tensor(state, dtype=torch.float).to(self.device)
        probs = self.actor(state)
        action_dist = torch.distributions.Categorical(probs)
        action = action_dist.sample()
        if share_ob is not None:
            share_ob = torch.tensor(share_ob, dtype=torch.float).to(self.device)
            value = self.critic(share_ob)
            return action.squeeze(),probs,value
        return action.squeeze(), probs

    def update(self, transition_dict):
        t0 = time.time()
        critic_state = torch.tensor(np.array(transition_dict['shared_obs']),
                              dtype=torch.float).to(self.device)
        critic_state = critic_state.view(-1,critic_state.shape[-1])
        actor_states = torch.tensor(np.array([state for state in transition_dict['states']]),
                              dtype=torch.float).to(self.device)
        actor_states = actor_states.view(-1,  actor_states.shape[-1])
        next_critic_state = torch.tensor( np.array(transition_dict['shared_next_obs']),
                              dtype=torch.float).to(self.device)
        next_critic_state = next_critic_state.view(-1, next_critic_state.shape[-1])
        actions = torch.tensor(np.array(transition_dict['actions'])).view(-1, 1).to(
            self.device)
        rewards = torch.tensor(np.array(transition_dict['rewards']),
                               dtype=torch.float).view(-1, 1).to(self.device)
        # next_states = torch.tensor(transition_dict['next_states'],
        #                            dtype=torch.float).to(self.device)
        dones = torch.tensor(np.array(transition_dict['dones']),
                             dtype=torch.float).view(-1, 1).to(self.device)
        death_mask = torch.tensor(transition_dict['death_mask'],
                                  dtype=torch.float).view(-1, 1).to(self.device)
        values = torch.tensor(np.array(transition_dict["value"]),dtype=torch.float).view(-1, 1).to(self.device)
        next_values = self.critic(next_critic_state)
        action_log_prob = torch.tensor(np.array(transition_dict["action_log_prob"]),dtype=torch.float)
        action_log_prob = action_log_prob.view(-1, action_log_prob.shape[-1]).to(self.device)
        td_target = rewards + self.gamma * next_values * (1 -  death_mask)
        num_steps = rewards.shape[0]
        last_gae = 0
        advantages = torch.zeros_like(rewards).to(device)


        t1 = time.time()
        for t in reversed(range(num_steps)):
            if t == num_steps - 1:
                next_values_t = next_values[t]
                next_non_terminal = death_mask[-1]
                delta = rewards[t] + gamma * next_values_t * next_non_terminal - values[t]
                advantages[t] = last_gae = delta + gamma * lmbda * next_non_terminal * last_gae
            else:
                next_values_t = values[t + 1]
                delta = rewards[t] + gamma * next_values_t * death_mask[t + 1] - values[t]
                advantages[t] = last_gae = delta + gamma * lmbda * next_non_terminal * last_gae
        t2 = time.time()
        returns = advantages + values
        value_target=rewards+self.critic(next_critic_state)

        dataset = Dataset(advantages,value_target, critic_state,next_critic_state, actor_states, action_log_prob, td_target, actions,rewards)
        dataloader = DataLoader(dataset, batch_size=len(dataset), shuffle=True)
        t2_5 = time.time()
        for i in range(5):
            # for j,(advantages,value_target, critic_state,next_critic_state, actor_states, action_log_prob, td_target, actions,rewards) in enumerate(dataloader):

            # self.naive_recurrent_generator(advantages,1)
            with torch.no_grad():
                old_log_probs = torch.log(action_log_prob.gather(1,actions)).detach()
                value_target = value_target.detach()
                advantages = advantages.detach()


        # torch.log(self.actor(actor_states).gather(1,
            #                                       actions)).detach()

            # log_probs = torch.log(self.actor(actor_states).gather(1,actions))
            log_probs, entropy = self.actor.evaluate_acts(actor_states,actions)
            ratio = torch.exp(log_probs - old_log_probs)
            surr1 = ratio * advantages
            surr2 = torch.clamp(ratio, 1 - self.eps,
                                1 + self.eps) * advantages  # 截断
            actor_loss = torch.mean(-torch.min(surr1, surr2))  # PPO损失函数,使熵尽可能大
            actor_loss = actor_loss - entropy*self.entropy_coefficient
            self.actor_optimizer.zero_grad()
            actor_loss.backward()#(retain_graph=True)

            critic_loss = torch.mean(F.mse_loss(value_target, self.critic(critic_state)))
            self.critic_optimizer.zero_grad()
            critic_loss.backward()#(retain_graph=True)
            self.actor_optimizer.step()
            self.critic_optimizer.step()
            t3 = time.time()
            print("t1:{:.2f} t2:{:.2f} t3:{:.2f} point_T{:.2f}".format((t1 - t0), (t2 - t1),(t3-t2),t2_5-t2))
    def feed_forward_generator(self,advantages, num_mini_batch):
        batch_size = 0
        mini_batch_size = 0
        num_mini_batch =0
        rand = torch.randperm(batch_size).numpy()
        sampler = [rand[i * mini_batch_size:(i + 1) * mini_batch_size] for i in range(num_mini_batch)]


def _t2n(x):
    return x.detach().cpu().numpy()
if __name__=="__main__":
    actor_lr = 3e-4
    critic_lr = 1e-3
    num_episodes = 100000
    hidden_dim = 256
    gamma = 0.99
    lmbda = 0.97
    eps = 0.2
    # device =  torch.device("cpu")
    # device =  torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    print("device :{}".format(device))
    empty_act = 0
    win_list = []
    episode_reward = []
    team_size = 4
    grid_size = (15, 15)
    episode_length = 500*4
    num_thread = 5
    envs = make_train_env(num_thread=num_thread)
    state_dim = envs.observation_space[0].shape[0]# * team_size
    action_dim = envs.action_space[0].n
    #5个智能体共享同一个策略
    agent = PPO(state_dim, hidden_dim, action_dim, actor_lr, critic_lr, lmbda, eps,
                gamma, device)
    for i in range(2):
        torch.save(agent,'agent0.pkl')
        with tqdm(total=int(num_episodes / 10), desc='Iteration %d' % i) as pbar:
            for i_episode in range(int(num_episodes / 10)):
                time0 = time.time()
                transition_dict_list = {
                    "value":[],
                    "action_log_prob":[],
                    'shared_obs':[],
                    'shared_next_obs':[],
                    'states': [],
                    'actions': [],
                    'next_states': [],
                    'rewards': [],
                    'death_mask':[],
                    'dones': []
                }
                s = envs.reset()
                terminal = False
                sum_reward = 0
                for episode_step in range(episode_length):
                    # 动作输出，并行化 5个rollout之间
                    # act_list = [[agent.take_action(s[i_thread][agent_i]) for agent_i in range(team_size)] for i_thread in range(num_thread)]
                    shared_obs = [[list(chain(*ob)) for i in range(len(ob))] for ob in s]
                    acts, probs, value = agent.take_action(np.concatenate(s),np.concatenate(shared_obs))
                    act_list = np.array(np.split(_t2n(acts),num_thread))
                    action_log_prob = np.array(np.split(_t2n(probs),num_thread))
                    value = np.array(np.split(_t2n(value),num_thread))
                    next_s, r, done, info = envs.step(act_list)
                    # print("reward",r,done,info)
                    # if i_episode%1000==0:
                        # env.render('human')
                    death_mask = np.zeros_like(info)#False if info['health'] == 0 else True
                    for i in range(death_mask.shape[0]):# if death_mask==1:
                        for j in range(death_mask.shape[1]):
                            death_mask[i][j] = info[i][0]['health'][j]>0

                    shared_next_obs = [[list(chain(*ob)) for i in range(len(ob))] for ob in next_s]
                    transition_dict_list['value'].append(value)
                    transition_dict_list['action_log_prob'].append(action_log_prob)
                    transition_dict_list['shared_obs'].append(shared_obs)
                    transition_dict_list['shared_next_obs'].append(shared_next_obs)
                    transition_dict_list['death_mask'].append(death_mask)
                    transition_dict_list['states'].append(s)
                    transition_dict_list['actions'].append(act_list)
                    transition_dict_list['next_states'].append(next_s)
                    transition_dict_list['rewards'].append(r)
                    transition_dict_list['dones'].append(done)
                    sum_reward+=sum(r)
                    episode_reward.append(sum_reward)
                    s = next_s
                # win_list.append(1 if info["win"] else 0)
                # for agent_i in range(team_size):
                time1 = time.time()
                agent.update(transition_dict_list)
                time2 = time.time()
                print("sample_t:{:.2f} train_t:{:.2f}".format((time1-time0),(time2-time1)))
                if (i_episode + 1) % 100 == 0:
                    pbar.set_postfix({
                        'episode':
                        '%d' % (num_episodes / 10 * i + i_episode + 1),
                        'return':
                        '%.3f' % np.mean(episode_reward[-100:]),
                        'win':
                            '%.3f' % np.mean(win_list[-100:])
                    })
                    write.add_scalar('reward',np.mean(episode_reward[-100:]),i_episode+i*num_episodes)
                pbar.update(1)

    win_array = np.array(win_list)
    #每100条轨迹取一次平均
    win_array = np.mean(win_array.reshape(-1, 100), axis=1)

    episodes_list = np.arange(win_array.shape[0]) * 100
    plt.plot(episodes_list, win_array)
    plt.xlabel('Episodes')
    plt.ylabel('Win rate')
    plt.title('IPPO on Combat')
    plt.show()